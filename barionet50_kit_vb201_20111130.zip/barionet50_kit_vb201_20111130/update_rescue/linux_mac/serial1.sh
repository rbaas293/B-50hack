#!/bin/bash
./seriald.sh /dev/ttyS0
